function main(){
	$( "#menu" ).load("menu.html");
	$( "#footer" ).load("footer.html");
	$( "#menu" ).load("menu.html");
	route();
	$(window).bind('hashchange', function() {
		route();
	});

}
function route(){
	var url = document.URL;
	if(url.indexOf('#')>0){
		var path = url.substring(url.indexOf('#')+1)
		console.log(path)
		loadToContent(path);
	} else loadToContent('home.html')
}
function loadToContent(page){
	$( "#content" ).empty();
	$( "#content" ).load(page);
}